## 集成Thymeleaf构建Web应用

这是一个最基本的SpringMVC工程，使用 Thymeleaf 3 作为模板引擎。

[Thymeleaf 3 官方教程](http://www.thymeleaf.org/doc/tutorials/3.0/usingthymeleaf.html)

## 许可证

Copyright (c) 2018 Xiong Neng

基于 MIT 协议发布: <http://www.opensource.org/licenses/MIT>
