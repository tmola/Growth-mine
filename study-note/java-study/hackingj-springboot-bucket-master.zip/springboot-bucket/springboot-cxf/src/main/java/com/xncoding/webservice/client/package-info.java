@javax.xml.bind.annotation.XmlSchema(namespace = "http://model.webservice.xncoding.com/")
package com.xncoding.webservice.client;
