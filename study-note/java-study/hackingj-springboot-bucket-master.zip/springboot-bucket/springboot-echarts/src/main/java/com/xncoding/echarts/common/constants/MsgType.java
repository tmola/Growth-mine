package com.xncoding.echarts.common.constants;

/**
 * 消息类型
 *
 * @author XiongNeng
 * @version 1.0
 * @since 2018/2/8
 */
public class MsgType {
    public static final String TYPE1 = "type1";
    public static final String TYPE2 = "type2";
}
