package com.xncoding.echarts.api.model.jmh;

/**
 * Title
 *
 * @author XiongNeng
 * @version 1.0
 * @since 2018/2/9
 */
public class Title {
    private String text;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
