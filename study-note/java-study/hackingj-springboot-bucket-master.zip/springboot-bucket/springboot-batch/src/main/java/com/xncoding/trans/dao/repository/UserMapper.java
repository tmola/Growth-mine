package com.xncoding.trans.dao.repository;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.xncoding.trans.dao.entity.User;

public interface UserMapper extends BaseMapper<User> {
}
