## SpringBoot Transaction演示项目

基于注解的声明式事务

## 测试方法

启动应用后访问/errorUpdate和/errorUpdate2，对于出现异常的Service方法，数据库会回滚。

## 许可证

Copyright (c) 2018 Xiong Neng

基于 MIT 协议发布: <http://www.opensource.org/licenses/MIT>
