## 异步线程池

演示在SpringBoot中如何使用异步线程池

## 测试用例

`com.xncoding.pos.ApplicationTests.java`

## 许可证

Copyright (c) 2018 Xiong Neng

基于 MIT 协议发布: <http://www.opensource.org/licenses/MIT>
