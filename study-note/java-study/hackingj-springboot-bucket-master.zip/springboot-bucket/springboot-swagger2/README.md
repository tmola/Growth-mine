
## 简介

集成Swagger2自动生成API文档，同时可转换成PDF格式

启动应用后访问：http://localhost:9095/swagger-ui.html

## 许可证

Copyright (c) 2018 Xiong Neng

基于 MIT 协议发布: <http://www.opensource.org/licenses/MIT>
