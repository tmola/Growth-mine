## RabbitMQ实现RPC调用客户端

消息队列RabbitMQ的使用例子，演示了RPC调用的客户端例子。

## 许可证

Copyright (c) 2018 Xiong Neng

基于 MIT 协议发布: <http://www.opensource.org/licenses/MIT>
