## 使用RestTemplate

使用RestTemplate访问RESTful API接口

## 测试用例

`com.xncoding.pos.ApplicationTests.java`

## 许可证

Copyright (c) 2018 Xiong Neng

基于 MIT 协议发布: <http://www.opensource.org/licenses/MIT>
