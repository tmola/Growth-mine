package com.xncoding.pos.dao.repository;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.xncoding.pos.dao.entity.User;

public interface UserMapper extends BaseMapper<User> {
}
